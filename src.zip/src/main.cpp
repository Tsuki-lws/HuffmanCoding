// 程序运行处
// #include "Utils.h"

// int main(int argc, char* argv[]) {


//     int choice = getEncodeOrDecode();
//     Execution(choice);
//     return 0;
// }

#include "utils.h"
int main(int argc, char* argv[]) {
    start();
    return 0;
}
