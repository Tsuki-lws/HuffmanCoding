// 程序运行处
#include "Utils.h"

int main() {
    int choice = getEncodeOrDecode();
    Execution(choice);
    return 0;
}