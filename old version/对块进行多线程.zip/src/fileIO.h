// 处理与文件的交互
#ifndef FILEIO_H
#define FILEIO_H

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <thread>
#include "HuffmanTree.h"

#define BUFFER_SIZE (512*1024)
using namespace std;

enum FileType {
    FILE_TYPE = 1,
    DIRECTORY = 0
};
// 文件头信息,单个文件
struct fileHead {
    int alphaVarity; // 字符种类数量
    long long originBytes; // 源文件字节数
    // int nameLength; // 文件名长度
    // char* name; // 文件名字符数组
     fileHead() : originBytes(0), alphaVarity(0){}
};
// 字母及其编码
struct alphaCode {
    char alpha;
    long long freq;
    alphaCode() {}
    alphaCode(const pair<char, long long>& x) : alpha(x.first), freq(x.second) {}
};
// 多线程所用变量
struct ThreadData {
    mutex mtx;
    condition_variable cv;
    queue<vector<char>> outputQueue;
    int threadsFinished = 0;
};
class FileIO{
    public:
        //压缩部分---------------------------------------------------------------

        // 读取单个文件内容并构建字符频率表
        map<char, long long> makeCharFreq(const string& filename);

        // 压缩单个文件
        void compressFile(const string& filename, const string& outputFileName, const string &prefix);
        //解压缩部分-------------------------------------------------------------

        //读取压缩文件头信息
        pair<fileHead,streampos> readFileHead(const string& filename,const streampos &startIndex);

        //读取压缩文件字符频度信息,构建哈夫曼树
        pair<map<char, long long>,streampos> readCompressTFileFreq(const string& filename,
                                                        int alphaVarity,streampos currentPos);
        // 解压缩单个文件
        streampos decompressFile(const string& filename,string& outputFileName,
                                        long long filesize,streampos startIndex);

        
    private:
        // 处理空文件
        void handleEmptyFile(const string &filename, const string &outputFileName, const string &prefix,
                                                                     ifstream &inputFile,ofstream &outputFile);

        // 处理非空文件
        string* handleNonEmptyFileHead(const string &filename,
                    const string &outputFileName, const string &prefix, ifstream &inputFile,ofstream &outputFile);
        
        // 处理一个块
        void processBlock(const char* inputBuffer, int blockSize, int& outputIndex, unsigned char& bits, int& bitcount, 
                  vector<char>& outputBuffer, ThreadData& threadData, string* charCodeArray);
        // 多线程处理
        void workerThread(ifstream& inputFile, long long startPos, long long endPos,
                                                        ThreadData& threadData, string* charCodeArray);
        // 写入目标文件
        void writeOutput(ofstream& outputFile, ThreadData& threadData);
        // 压缩文件的主体内容
        void processFile(const string& inputFilename,const string& outputFilename, string* charCodeArray,
                                                         ifstream &inputFile,ofstream &outputFile);
};
#endif